//#define  GLM_FORCE_RADIANS
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cmath>
#include <fstream>
#include <vector>
#include <GL/glew.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "imageloader.h"


using namespace std;


class Terrain
{
	private:
		int w;
		int l;
		float** hs;
	//	glm::vec3 *normals;
	//	bool computedNormals;

	public:
			Terrain(int w2, int l2) 
			{
				w = w2;
				l = l2;
				
				hs = new float*[l];
				for(int i = 0; i < l; i++) 
					hs[i] = new float[w];
				
				
	//			normals = new glm::vec3[l];
	//			computedNormals = false;
			}
		
		~Terrain() 
		{
			for(int i = 0; i < l; i++) {
				delete[] hs[i];
			}
			delete[] hs;
			
			
			
		}

		int width()
		{
			return w;
		}
		
		int length() 
		{
			return l;
		}
		
		//Sets the height at (x, z) to y
		void setHeight(int x, int z, float y) 
		{
			hs[z][x] = y;
//			computedNormals = false;
		}
		
		//Returns the height at (x, z)
		float getHeight(int x, int z) 
		{
			return hs[z][x];
		}
		
				
		
};

Terrain* loadTerrain(const char* filename, float height) 
{
	Image* image = loadBMP(filename);
	Terrain* t = new Terrain(image->width, image->height);
	for(int y = 0; y < image->height; y++) 
	{
		for(int x = 0; x < image->width; x++) 
		{
			unsigned char color =
				(unsigned char)image->pixels[3 * (y * image->width + x)];
			float h = height * ((color / 255.0f) - 0.5f);
			t->setHeight(x, y, h);
		}
	}
	
	delete image;
	//t->computeNormals();
	return t;
}


Terrain* _terrain;

void cleanup() 
{
	delete _terrain;
}

struct GLMatrices
{
	glm::mat4 projection;
	glm::mat4 model;
	glm::mat4 view;
	GLuint MatrixID;
} Matrices;

GLuint programID;
GLuint VertexArrayID[2];
GLuint vertexbuffer[2];
GLuint colorbuffer[2];
float camera_rotation_angle = 0;
int count;

/* Function to load Shaders - Use it as it is */
GLuint LoadShaders(const char * vertex_file_path,const char * fragment_file_path) {

	// Create the shaders
	GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
	GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

	// Read the Vertex Shader code from the file
	std::string VertexShaderCode;
	std::ifstream VertexShaderStream(vertex_file_path, std::ios::in);
	if(VertexShaderStream.is_open())
	{
		std::string Line = "";
		while(getline(VertexShaderStream, Line))
			VertexShaderCode += "\n" + Line;
		VertexShaderStream.close();
	}

	// Read the Fragment Shader code from the file
	std::string FragmentShaderCode;
	std::ifstream FragmentShaderStream(fragment_file_path, std::ios::in);
	if(FragmentShaderStream.is_open()){
		std::string Line = "";
		while(getline(FragmentShaderStream, Line))
			FragmentShaderCode += "\n" + Line;
		FragmentShaderStream.close();
	}

	GLint Result = GL_FALSE;
	int InfoLogLength;

	// Compile Vertex Shader
	printf("Compiling shader : %s\n", vertex_file_path);
	char const * VertexSourcePointer = VertexShaderCode.c_str();
	glShaderSource(VertexShaderID, 1, &VertexSourcePointer , NULL);
	glCompileShader(VertexShaderID);

	// Check Vertex Shader
	glGetShaderiv(VertexShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(VertexShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	std::vector<char> VertexShaderErrorMessage(InfoLogLength);
	glGetShaderInfoLog(VertexShaderID, InfoLogLength, NULL, &VertexShaderErrorMessage[0]);
	fprintf(stdout, "%s\n", &VertexShaderErrorMessage[0]);

	// Compile Fragment Shader
	printf("Compiling shader : %s\n", fragment_file_path);
	char const * FragmentSourcePointer = FragmentShaderCode.c_str();
	glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer , NULL);
	glCompileShader(FragmentShaderID);

	// Check Fragment Shader
	glGetShaderiv(FragmentShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(FragmentShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	std::vector<char> FragmentShaderErrorMessage(InfoLogLength);
	glGetShaderInfoLog(FragmentShaderID, InfoLogLength, NULL, &FragmentShaderErrorMessage[0]);
	fprintf(stdout, "%s\n", &FragmentShaderErrorMessage[0]);

	// Link the program
	fprintf(stdout, "Linking program\n");
	GLuint ProgramID = glCreateProgram();
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
	glLinkProgram(ProgramID);

	// Check the program
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &Result);
	glGetProgramiv(ProgramID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	std::vector<char> ProgramErrorMessage( max(InfoLogLength, int(1)) );
	glGetProgramInfoLog(ProgramID, InfoLogLength, NULL, &ProgramErrorMessage[0]);
	fprintf(stdout, "%s\n", &ProgramErrorMessage[0]);

	glDeleteShader(VertexShaderID);
	glDeleteShader(FragmentShaderID);

	return ProgramID;
}

/* Executed when a regular key is pressed */
void keyboardDown (unsigned char key, int x, int y)
{
	switch (key) {
		case 'Q':
		case 'q':
		case 27: //ESC
			exit (0);
		default:
			break;
	}
}

/* Executed when a regular key is released */
void keyboardUp (unsigned char key, int x, int y)
{
	switch (key) {
		case 'a':
			// do something
			break;
		default:
			break;
	}
}

/* Executed when a special key is pressed */
void keyboardSpecialDown (int key, int x, int y)
{
}

/* Executed when a special key is released */
void keyboardSpecialUp (int key, int x, int y)
{
}

/* Executed when a mouse button 'button' is put into state 'state' 
   at screen position ('x', 'y') 
 */
void mouseClick (int button, int state, int x, int y)
{
}

/* Executed when the mouse moves to position ('x', 'y') */
void mouseMotion (int x, int y)
{
}


/* Executed when window is resized to 'width' and 'height' */
void reshapeWindow (int width, int height)
{
	GLfloat fov = 90.0f;

	// sets the viewport of openGL renderer
	glViewport (0, 0, (GLsizei) width, (GLsizei) height);

	// set the projection matrix as perspective
	/* glMatrixMode (GL_PROJECTION);
	   glLoadIdentity ();
	   gluPerspective (fov, (GLfloat) width / (GLfloat) height, 0.1, 500.0); */
	// Store the projection matrix in a variable for future use
	Matrices.projection = glm::perspective (fov, (GLfloat) width / (GLfloat) height, 0.1f, 500.0f);
}

void setcoord(GLfloat* coordinates,int x,int y,int z)
{
	coordinates[count++] = x;
	coordinates[count++] = y;
	coordinates[count++] = z;
}
void createTerrain()
{
	vector< glm::vec3 > vertices;
	count = 0;
	
	int l = (int)_terrain->length();
	int h = (int)_terrain->width();
	GLfloat coordinates[(l-1)*h*6];
	for(int z = 0; z < _terrain->length() - 1; z++)
	{
		if(z%2==0)
		{
			for(int x = 0; x < _terrain->width(); x++)
			{
				setcoord(coordinates, x, _terrain->getHeight(x, z), z);
				setcoord(coordinates, x, _terrain->getHeight(x, z + 1), z + 1);
				
			}
		}
		else
		{
			int a = (int )_terrain->width();
			for(int x = a-1; x >= 0; x--)
			{
				setcoord(coordinates, x, _terrain->getHeight(x, z), z);
				setcoord(coordinates, x, _terrain->getHeight(x, z + 1), z + 1);
				
			}	
		}
		
	}
//	if(count*3 == (l-1)*h*6)
	

	
	printf("%d\n",count/3 );

	glBindVertexArray(VertexArrayID[0]);

	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*(l-1)*h*6, coordinates, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void *)0);

	glBindVertexArray(0);
}

void drawTerrain()
{
	glBindVertexArray(VertexArrayID[0]);
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer[0]);
	glVertexAttrib3f((GLuint)1, 0.0, 1.0, 0.0);
	glDrawArrays(GL_TRIANGLE_STRIP, 0, count/3);
}
void draw ()
{
	// clear the color and depth in the frame buffer
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// use the loaded shader program
	glUseProgram (programID);

	glm::vec3 eye ( 0,0,-4.5 );
	glm::vec3 target (0, 0, 0);
	glm::vec3 up (0, 1, 0);

	// Compute Camera matrix (view)
	Matrices.view = glm::lookAt( eye, target, up );

	// Load identity to model matrix
	Matrices.model = glm::mat4(1.0f);

	// Compute ViewProject matrix as view/camera might not be changed for this frame (basic scenario)
	glm::mat4 VP = Matrices.projection * Matrices.view;
	glm::mat4 Trans = glm::translate(glm::vec3(0.f,0.f,-11.f));
	//glm::mat4 Trans = glm::translate(glm::vec3(0.f,0.f,-7.f));
	glm::mat4 Rotation = glm::rotate(0.f,glm::vec3(1.f,0.f,0.f));
	float scale = 5.0f / max(_terrain->width() - 1, _terrain->length() - 1);
	glm::mat4 Scale = glm::scale(glm::vec3(scale,scale,scale));
	glm::mat4 MVP;	// MVP = Projection * View * Model

	Matrices.model *= Scale*Rotation*Trans;
	Trans = glm::translate(glm::vec3(-(float)(_terrain->width() - 1) / 2,
				 0.0f,
				 -(float)(_terrain->length() - 1) / 2));
	//Rotation
	/* Render your scene */
	Matrices.model *= Trans;
	MVP = VP * Matrices.model; // MVP = p * V * M
	glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
	drawTerrain();
		
	// swap the frame buffers
	glutSwapBuffers ();
//camera_rotation_angle++;
	
}

void idle ()
 {
	// OpenGL should never stop drawing
	// can draw the same scene or a modified scene
	draw (); // drawing same scene
}

/* Initialise glut window, I/O callbacks and the renderer to use */
void initGLUT (int& argc, char** argv, int width, int height)
{
	// Init glut
	glutInit (&argc, argv);
	
	// Init glut window
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitContextVersion (3, 3); // Init GL 3.3
	glutInitContextFlags (GLUT_CORE_PROFILE); // Use Core profile - older functions are deprecated
	glutInitWindowSize (width, height);
	glutCreateWindow ("SpinningTop");
	
	// Initialize GLEW, Needed in Core profile
	glewExperimental = GL_TRUE;
	GLenum err = glewInit();
	if (err != GLEW_OK) {
		cout << "Error: Failed to initialise GLEW : "<< glewGetErrorString(err) << endl;
		exit (1);
	}

	// register glut callbacks
	glutKeyboardFunc (keyboardDown);
	glutKeyboardUpFunc (keyboardUp);

	glutSpecialFunc (keyboardSpecialDown);
	glutSpecialUpFunc (keyboardSpecialUp);

	glutMouseFunc (mouseClick);
	glutMotionFunc (mouseMotion);

	glutReshapeFunc (reshapeWindow);

	glutDisplayFunc (draw); // function to draw when active
	glutIdleFunc (idle); // function to draw when idle (no I/O activity)

	glutIgnoreKeyRepeat (true); // Ignore keys held down
}

void initGL (int width, int height)
{
	// Create Vertex Array Object
	// Should be done after CreateWindow and before any other GL calls
	glGenVertexArrays(2, &VertexArrayID[0]); // VAO
	glGenBuffers (2, &vertexbuffer[0]); // VBO - vertices
	glGenBuffers (2, &colorbuffer[0]);  // VBO - colors
	
	createTerrain();
	
	// Create and compile our GLSL program from the shaders
	programID = LoadShaders( "VertexShader.vert", "FragmentShader.frag" );
	// Get a handle for our "MVP" uniform
	Matrices.MatrixID = glGetUniformLocation(programID, "MVP");

	
	reshapeWindow (width, height);

	glClearColor (1.0f, 0.f, 0.0f, 0.0f);
	glClearDepth (1.0f);

	glEnable (GL_DEPTH_TEST);
	glDepthFunc (GL_LEQUAL);
}



int main (int argc, char** argv)
{
	int width = 800;
	int height = 600;
	_terrain = loadTerrain("heightmap.bmp", 20.f);
	initGLUT (argc, argv, width, height);

	//adddGLUTMenus ();

	initGL (width, height);


	glutMainLoop ();

	return 0;
}
